const FileNamePlugin = require('./build/file_name_plugin/plugin');

module.exports = FileNamePlugin;
