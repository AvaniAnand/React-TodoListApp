const TestNamePlugin = require('./build/test_name_plugin/plugin');

module.exports = TestNamePlugin;
