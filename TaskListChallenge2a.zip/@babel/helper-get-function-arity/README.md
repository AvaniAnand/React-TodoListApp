# @babel/helper-get-function-arity

> Helper function to get function arity

See our website [@babel/helper-get-function-arity](https://babeljs.io/docs/en/babel-helper-get-function-arity) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/helper-get-function-arity
```

or using yarn:

```sh
yarn add @babel/helper-get-function-arity --dev
```
